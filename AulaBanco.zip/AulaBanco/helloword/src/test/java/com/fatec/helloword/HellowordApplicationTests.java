package com.fatec.helloword;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HellowordApplicationTests {

	@Test
	void contextLoads() {
	}

}
